import React from 'react';
import "../Reuseable/Reuseable.css"

const Logo = () => {
    return (
        <p >
           <span className='fs-2 ff-t fs-48 text-prim'>Mal</span>
            <span className='ff-p fw-400 fs-32'>d</span>
            <span className='fs-3 ff-p fw-500 fs-32' >ives</span>
        </p>
    )
}

export default Logo;
